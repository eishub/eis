package actions;

import static org.junit.Assert.*;
import grid.Direction;
import grid.Grid;
import grid.GridObject;
import grid.GridPoint;
import grid.ModelListener;
import grid.MovingObject;
import grid.Square;

import org.jmock.Expectations;
import org.jmock.Mockery;
import org.jmock.Sequence;
import org.jmock.integration.junit4.JUnit4Mockery;
import org.junit.Before;
import org.junit.Test;


public class MoveTests {
	
	// 3 x 3 grid with moving thing in south middle square
	private final Grid testGrid = new Grid(3, 3);
	Mockery context = new JUnit4Mockery();
	final ModelListener listener = context.mock(ModelListener.class);
	final Sequence moveSteps = context.sequence("turn steps");
	
	@Before public void setup() {
		new GridObject(testGrid, new GridPoint(2,2));
	}

	@Test public void oneSquareMoveTest() throws InterruptedException,
			ImpossibleActionException, UnavailableActionException {
		final MovingThing thing = new MovingThing(Direction.north);
		thing.addListener(listener);
		context.checking(new Expectations() {{
			exactly(1).of (listener).eventFired(
					with(equal("actions.Move.start")), with(equal(thing))); inSequence(moveSteps);
			exactly(31).of (listener).eventFired(
					with(equal("actions.Move.step")), with(equal(thing))); inSequence(moveSteps);
			exactly(1).of (listener).eventFired(
					with(equal("actions.Move.stop")), with(equal(thing))); inSequence(moveSteps);
		}});
		Move move = new Move(thing);
		move.execute();
		assertEquals(1.0, thing.getY(), 0.001);
	}
	
	@Test (expected=ImpossibleActionException.class)
	public void impossibleOneSquareMoveTest() throws InterruptedException,
			ImpossibleActionException, UnavailableActionException {
		final MovingThing thing = new MovingThing(Direction.south);
		Move move = new Move(thing);
		try {
			move.execute();
		} finally {
			assertEquals(1.0, thing.getX(), 0.001);
			assertEquals(2.0, thing.getY(), 0.001);
		}
	}
	

	
	public class MovingThing extends MovingObject {

		public MovingThing(Direction direction) {
			super(testGrid, new GridPoint(1, 2), direction);
		}

		public long getTimeToMove() {
			return 40;
		}

		public long getTimeToTurn() {
			return 0;
		}

		public GridObject getObstruction(Square square) {
			return null;
		}
		
	}
	
}
