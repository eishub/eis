package log;

import static org.junit.Assert.*;

import grid.Grid;
import grid.GridObject;
import grid.GridPoint;
import grid.ModelListener;

import java.io.PrintStream;

import log.StreamEventLogger;

import org.junit.Test;

public class StreamEventLoggerTests {

	private final Grid world = new Grid(2, 2);
	private final GridPoint point = new GridPoint(1, 1);
	private final TestGridObject testGridObject = new TestGridObject(world, point);
	
	@Test public void addLoggingListenerTest() {
		// Next line should register the logger as an observer with testGridObject
		StreamEventLogger streamEventLogger = new StreamEventLogger(testGridObject, System.out);
		// Check that the observer was registered
		assertEquals(streamEventLogger, testGridObject.lastListener);
	}
	
	@Test public void simpleEventTest() {
		TestStream testStream = new TestStream();
		String eventName = "TestEvent";
		// Register the logger with the grid object
		new StreamEventLogger(testGridObject, testStream);
		testGridObject.fireEvent(eventName, null);
		assertNotNull(testStream.lastLine);
		// Check the event contains the source name
		assertTrue(testStream.lastLine.contains(testGridObject.toString()));
		// Check the event contains the event name
		assertTrue(testStream.lastLine.contains(eventName));
	}
	
	@Test (expected=IllegalArgumentException.class) 
	public void nullEventTest() {
		TestStream testStream = new TestStream();
		// Register the logger with the grid object
		new StreamEventLogger(testGridObject, testStream);
		testGridObject.fireEvent(null, null);
		assertNotNull(testStream.lastLine);
		// Check the event contains the source name
		assertTrue(testStream.lastLine.contains(testGridObject.toString()));
	}
	
	private static class TestGridObject extends GridObject {
		
		public ModelListener lastListener = null;
		
		public TestGridObject(Grid world, GridPoint location) {
			super(world, location);
		}
		
		@Override
		// Additionally allows client to retrieve the most recently-added PCL
		public void addListener(ModelListener listener) {
			super.addListener(listener);
			this.lastListener = listener;	
		}

	}
	
	private static class TestStream extends PrintStream {

		public String lastLine = null;
		
		// Wrap around System.out
		public TestStream() {
			super(System.out);
		}
		
		@Override
		// Don't print anything, instead keep a reference to the string
		public void println(String line) {
			this.lastLine = line;
		}
	}
}
