package grid;

import static org.junit.Assert.*;

import org.junit.Test;

public class DirectionTests {
	
	@Test public void add01Test() {
		Direction d = new Direction(0.1);
		d.setValue(d.getRadians() + 0.1);
		assertEquals(0.2, d.getRadians(), 0.01);
	}
	
	@Test public void add61Test() {
		Direction d = new Direction(0.1);
		d.setValue(d.getRadians() + 6.1);
		assertEquals(6.2, d.getRadians(), 0.01);
	}
	
	@Test public void add62Test() {
		Direction d = new Direction(0.1);
		d.setValue(d.getRadians() + 6.2);
		assertEquals(6.3 - (Math.PI * 2), d.getRadians(), 0.01);
	}
	
	@Test (expected=IllegalArgumentException.class)
	public void changeFixedDirectionTest() {
		Direction.north.setValue(3);
	}
	
	@Test public void randomDirectionTest() {
		int northCount = 0;
		int southCount = 0;
		int eastCount = 0;
		int westCount = 0;
		for (int i = 0; i < 100; i++) {
			Direction d = Direction.random();
			if (d.equalsDirection(Direction.north)) northCount++;
			else if (d.equalsDirection(Direction.east)) eastCount++;
			else if (d.equalsDirection(Direction.south)) southCount++;
			else if (d.equalsDirection(Direction.west)) westCount++;
			else fail("Expected N|S|E|W from Direction.random(), but value was " + d.getRadians() + " radians!");
		}
		assertTrue(northCount > 10);
		assertTrue(southCount > 10);
		assertTrue(eastCount > 10);
		assertTrue(westCount > 10);
	}

	@Test public void round01Test() {
		Direction d = new Direction(0.1);
		assertEquals(d.round(), Direction.north);
	}
	
	@Test public void round02Test() {
		Direction d = new Direction(0.2);
		assertEquals(d.round(), Direction.north);
	}
	
	@Test public void round03Test() {
		Direction d = new Direction(0.3);
		assertEquals(d.round(), Direction.north);
	}
	
	@Test public void round08Test() {
		Direction d = new Direction(0.8);
		assertEquals(d.round(), Direction.east);
	}
	
	@Test public void round54Test() {
		Direction d = new Direction(5.4);
		assertEquals(d.round(), Direction.west);
	}
	
	@Test public void round55Test() {
		Direction d = new Direction(5.5);
		assertEquals(d.round(), Direction.north);
	}
	
	@Test public void round62Test() {
		Direction d = new Direction(6.2);
		assertEquals(d.round(), Direction.north);
	}
	
	@Test public void round63Test() {
		Direction d = new Direction(6.3);
		assertEquals(d.round(), Direction.north);
	}
}
