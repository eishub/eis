package grid;

import static org.junit.Assert.*;

import java.util.Iterator;

import org.junit.Test;

public class GridRandomIteratorTests {

	@Test public void randomIteratorTest() {
		boolean[][] visited = new boolean[8][6]; // All default to false
		Grid g = new Grid(8,6);
		Iterator<Square> it = g.randomIterator();
		int visits = 0;
		while (it.hasNext()) {
			Square s = it.next();
			visited[s.location.x][s.location.y] = true;
			visits++;
		}
		assertEquals(48, visits);
		for (int i = 0; i < 8; i++) {
			for (int j = 0; j < 6; j++) {
				assertTrue(visited[i][j]);
			}
		}
	}
	
}
