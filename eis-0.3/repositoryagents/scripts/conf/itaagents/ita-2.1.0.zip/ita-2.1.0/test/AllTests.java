

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)
@Suite.SuiteClasses( {
	grid.DirectionTests.class,
	grid.SquareTests.class,
	grid.MovingObjectTests.class,
	grid.NearestPointTests.class,
	grid.GridRandomIteratorTests.class,
	grid.ListenerRegistrationTests.class,
	actions.ActionTests.class,
	actions.TurnTests.class,
	actions.MoveTests.class,
	log.StreamEventLoggerTests.class,
	vac.VacBotTests.class,
	vac.VacWorldGeneratorTests.class,
	vac.VacWorldParserTests.class,
	ei.CreateAndTestEiJar.class,
	ei.EiTests.class
})

public class AllTests {}

