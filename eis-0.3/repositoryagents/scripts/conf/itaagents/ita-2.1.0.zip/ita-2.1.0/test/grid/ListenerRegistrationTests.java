package grid;

import static org.junit.Assert.*;
import gui.DustView;
import gui.VacBotView;

import java.util.Iterator;

import org.junit.Test;

import vac.Dust;
import vac.VacBot;
import vac.VacWorld;

/**
 * These are really end-to-end tests for functionality spread over the vac, grid, and gui packages.
 * The tests are in this package, to allow direct access to grid.ModelObject.listeners.
 */
public class ListenerRegistrationTests {
	
	@Test public void guiListenerRegistrationTest() {
		VacWorld vw = new VacWorld(8);
		vw.show(); // Registers the required gui listeners
		
		for (VacBot vb : vw.getVacBots()) {
			assertTrue(vb.listeners.size() >=1);
			int vacBotViewCount = 0;
			for (ModelListener ml : vb.listeners) {
				if (ml.getClass().equals(VacBotView.class)) vacBotViewCount++;
			}
			assertEquals(1, vacBotViewCount);
		}
		
		Iterator<Square> it = vw.grid.scanIterator();
		while (it.hasNext()) {
			Square square = it.next();
			if (square.has(Dust.class)) {
				Dust d = (Dust) square.getInstanceOf(Dust.class);
				assertTrue(d.listeners.size() >= 1);
				int dustViewCount = 0;
				for (ModelListener ml : d.listeners) {
					if (ml.getClass().equals(DustView.class)) dustViewCount++;
				}
				assertEquals(1, dustViewCount);
			}
		}
		
		vw.close();
	}
}
