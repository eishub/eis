package ei;

import static org.junit.Assert.*;

import java.io.File;
import java.io.IOException;
import java.util.LinkedList;
import java.util.List;


import org.junit.BeforeClass;
import org.junit.Test;

import util.filesystem.ImprovedFile;
import util.filesystem.JarCreator;

public class CreateAndTestEiJar {
	
	private static final String pathToClasses = "bin";
	private static final String mainClass = "ei.Ei";
	
	@BeforeClass public static void createEiJar() throws IOException {
		List<String> fileNames =
            new ImprovedFile(pathToClasses).findRecursivelyByRegex(".*class",".*Test.*");
		List<String> relativeFileNames = new LinkedList<String>();
		for (String fileName : fileNames) {
			relativeFileNames.add(fileName.replace(pathToClasses + "/", ""));
		}
		new JarCreator().createStructuredExecutableJar(
            EiTests.jarName, pathToClasses, relativeFileNames.toArray(new String[0]),mainClass);
	}
	
	@Test public void jarFileNotEmptyTest() {
		File jarFile = new File(EiTests.jarName);
		assertTrue(jarFile.exists());
		assertTrue(jarFile.isFile());
		assertTrue(jarFile.length() > 208); // Size of the Jar with manifest only
	}

}

