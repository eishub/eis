package util.test;

import java.util.List;

public class StringListTester {

	private final List<String> list;
	
	public StringListTester(List<String> list) {
		this.list = list;
	}
	
	public boolean contains(String testString) {
		for (String stringInList : list) {
			if (stringInList.equals(testString)) return true;
		}
		return false;
	}
}
