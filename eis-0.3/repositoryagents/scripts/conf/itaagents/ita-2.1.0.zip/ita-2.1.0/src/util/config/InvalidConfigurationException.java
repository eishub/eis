package util.config;

public class InvalidConfigurationException extends Exception {

	private static final long serialVersionUID = -4721423541730141427L;

	public InvalidConfigurationException(String message) {
		super(message);
	}
	
}
