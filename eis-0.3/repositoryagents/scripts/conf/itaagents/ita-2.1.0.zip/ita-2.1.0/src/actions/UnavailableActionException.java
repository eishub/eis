package actions;

@SuppressWarnings("serial")
public class UnavailableActionException extends Exception {

	public UnavailableActionException(String message) {
		super(message);
	}

}
