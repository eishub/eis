package vac;

public class InvalidVacWorldException extends Exception {

	private static final long serialVersionUID = 532442651226316678L;

	public InvalidVacWorldException(String message) {
		super(message);
	}
}
